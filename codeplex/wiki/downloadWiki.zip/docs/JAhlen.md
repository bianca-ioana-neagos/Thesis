This project contains the source code for my articles about StreamInsight on [www.sqlservercentral.com](www.sqlservercentral.com).

**Example screenshots**
![](JAhlen_Twitter.gif)

![](JAhlen_Yahoo.gif)

**Read more about StreamInsight at my blog:**
[http://www.joinsights.com](http://www.joinsights.com)
