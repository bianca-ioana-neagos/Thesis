StreamInsight on CodePlex is a community-driven space for sample code that uses the StreamInsight framework API.

For more information about the individual contributions, please follow the links below:

* [The StreamInsight Product Team](The-StreamInsight-Product-Team)
* [JAhlen](JAhlen)
* [greglow](greglow)
* [rseroter](rseroter)

The HighwayMonitor simulation system that Greg Low created for the SQL Server Metro program is available from the SQL Server 2008 R2 Developers Toolkit available here: [http://go.microsoft.com/?linkid=9710868](http://go.microsoft.com/?linkid=9710868). The toolkit also contains video presentations and demonstrations on using StreamInsight. 