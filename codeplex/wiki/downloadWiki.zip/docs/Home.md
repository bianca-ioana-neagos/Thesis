**Project Description**
This project contains sample code for StreamInsight, Microsoft's platform for complex event processing.

The StreamInsight CodePlex project contains samples contributed by the StreamInsight Product Team as well as third parties. If you are interested in contributing, please contact either Greg (greglow) or Roman (rschindlauer) through the "People" tab!
You can download each contribution separately from the Downloads tab or the entire source code collection from the Source code tab.

_To see a list of the contributions, go to the [Documentation](Documentation) page._