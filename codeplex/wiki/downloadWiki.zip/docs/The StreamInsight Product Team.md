# StreamInsight V2.1
To demonstrate the new APIs in [StreamInsight V2.1](http://go.microsoft.com/fwlink/?LinkID=253700), we have created the [release:90143](release_90143) that co-exist with the samples for previous versions (V2.0 and below).

||Application||Purpose||
|HelloWorld|Simple StreamInsight application to get started.|
|ComposingQueries|Shows how to compose queries in comparison with the same application in the V2.0 sample set.|
|ComposingQueriesNoAdapter|Same as above, but using .Net sequence integration instead of adapters.|
|Checkpointing|Shows how to take checkpoints and recover from interruptions.|
|Hitchhiker_V21|Accompanies the updated version of the [Hitchhiker's Guide to StreamInsight Queries](http://go.microsoft.com/fwlink/?LinkId=256236).|
|UdsoPatternDetector|Demonstrates how to use a User-defined StreamOperator (UDSO) to implement a complex pattern detection scenario.|
|WCF|Shows how to send and receive events via WCF.|

# StreamInsight V2.0
The [release:46435](release_46435) are demonstrating key aspects of the StreamInsight CEP platform. The purpose of the samples is to provide a guide through the StreamInsight development experience, demonstrating common design patterns for adapters, queries, and applications. The emphasis is on the teaching character, not on feature completeness, performance, or robustness. [Follow the product team on Twitter](http://twitter.com/streaminsight) for latest updates.

The samples consist of a set of Visual Studio Solutions, each of which contains at least one input adapter, one output adapter, and one main application. Each adapter is a separate projects and can be included in multiple solutions.

||Adapter||Purpose||Teaching Value||VS Version||
|DataGenerator (IA)|Generates events with random payload values|Event push model (through a callback); simple implementation of the adapter state diagram|2008|
|OutputTracer (OA)|Traces output events on the console or a file|Simple untyped output adapter design; useful for prototyping and testing|2008|
|SimpleTextFileReader (IA)|Reads lines from a csv file and transforms them into events|Simple untyped input adapter|2008|
|SimpleTextFileWriter (OA)|Writes events as lines to a file in csv format|Simple untyped output adapter|2008|
|WcfAdapter (IA, OA)|Reads and writes events from and to ECF endpoints|Simple remoting of event streams|2008|
|AsyncCsv (IA, OA)|Reads (asynchronously) and writes events from and to csv files| Using IO completion for efficient file reading; using an adapter class abstraction for point/interval/edge|2008|
|SQL (IA, OA)|Reads and writes events from and to SQL Server tables|Using a SqlDataReader to interface with SQL; Writing an untyped adapter|2008|

||Application||Purpose||Teaching Value||VS Version||
|ComposingQueries|Applies two subsequent queries to data from the DataGenerator and dumps the result on the console|Use dynamic query composition to stream into two output adapters|2008|
|TrafficJoinQuery|Reads and processes traffic data from two text files|Use the explicit query binder model; join two input streams|2008|
|WcfApplication|Applies a query to an event stream from a WCF endpoint|Demonstrates the usage of the WCF adapters with a simple query|2008|
|PatternDetector|Uses a user-defined operator to implement a pattern matcher on csv input data|Implementing a state machine through the extensibility framework|2008|
|Hitchhiker|Contains the sample queries used in the ["Hitchhiker's Guide"](http://blogs.msdn.com/b/streaminsight/archive/2010/06/08/hitchhiker-s-guide-to-streaminsight-queries.aspx) paper|Various query patterns|2008|
|SequenceIntegration|Hitchhiker queries; Performance Counter import; Northwind DB temporal queries|Shows how to use .NET sequences to use files, perf counters, OData feeds as event sources, and WPF elements as event sinks|2010|
|SqlApplication|Applies a temporal query against SQL input data|Demonstrates the usage of the SQL adapters with a simple query|2008|