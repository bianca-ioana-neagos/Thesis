﻿========================================
RandomDataGenerator
========================================

Last change: 10 June 2011

This is a simple program that generates random comma-separated value (CSV)
files for use with the Checkpointing Sample.