========================================
HelloWorld Sample for StreamInsight 2.1
========================================

Last change: 6/21/2012

This sample simulates data from live or historic streams from sensor reading. A query is detecting when a threshold is crossed upwards. This result is shown to console window when crossed upwards happens. 

This sample demonstrates the following aspects:

  * Live data uses IQbservable<> to generate data stream
  * Historic data uses IQueryable<> to generate data stream
  * Simple join query

  